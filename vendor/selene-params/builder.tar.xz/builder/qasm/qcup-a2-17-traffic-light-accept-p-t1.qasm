OPENQASM 3.0;
include "stdgates.inc";
gate rzz(p0) _gate_q_0, _gate_q_1 {
  cx _gate_q_0, _gate_q_1;
  rz(p0) _gate_q_1;
  cx _gate_q_0, _gate_q_1;
}
bit[2] trace;
qubit[2] s_0;
ry(pi/2) s_0[0];
rx(-2.150915695502496) s_0[0];
ry(pi) s_0[1];
rzz(-pi/2) s_0[1], s_0[0];
rx(pi/2) s_0[0];
ry(pi) s_0[0];
rx(pi/2) s_0[1];
ry(pi) s_0[1];
rzz(-pi/2) s_0[1], s_0[0];
rx(-2.150915695502496) s_0[1];
ry(pi/2) s_0[1];
trace[0] = measure s_0[0];
trace[1] = measure s_0[1];
